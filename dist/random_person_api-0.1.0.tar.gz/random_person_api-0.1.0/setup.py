# -*- coding: utf-8 -*-
from setuptools import setup

modules = \
['random_person_api']
setup_kwargs = {
    'name': 'random-person-api',
    'version': '0.1.0',
    'description': '',
    'long_description': None,
    'author': 'Dipen Shah',
    'author_email': 'dipenmshah8@gmail.com',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'py_modules': modules,
    'python_requires': '>=3.9,<4.0',
}


setup(**setup_kwargs)
